"""
WiseOldMan Clan Analytics Dashboard

Streamlit app for tracking OSRS clan activity and player progression.
"""

__version__ = "1.0.0"
